# MAP README

0 - Black - Triggers
1 - Yellow - Walls
2 - Red - Doors
3 - Green - Stairs up
4 - Blue - Stairs down
5 - Purple - Chests 

Tile size tem que ser 3px X 3px durante a driação de mapas
