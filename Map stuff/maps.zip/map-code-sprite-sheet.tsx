<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="map-code-sprite-sheet" tilewidth="3" tileheight="3" spacing="1" margin="1" tilecount="64" columns="8">
 <image source="map-code-sprite-sheet.png" width="32" height="32"/>
</tileset>
